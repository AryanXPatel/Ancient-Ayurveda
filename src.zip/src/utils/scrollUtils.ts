export const scrollToTop = () => {
  window.scrollTo({ top: 0, left: 0, behavior: "instant" });
};

export const smoothScrollToTop = () => {
  window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
};
